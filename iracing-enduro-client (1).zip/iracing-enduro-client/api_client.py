import requests
import threading
import time
from config import load_config, SERVER_URL

_lock = threading.Lock()
_last_position_post = 0
POSITION_POST_INTERVAL = 3  # seconds — only push standings every 3s


def _get_headers() -> dict:
    cfg = load_config()
    token = cfg.get("token", "")
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


def login(username: str, password: str) -> dict:
    r = requests.post(
        f"{SERVER_URL}/api/auth/login",
        json={"username": username, "password": password},
        timeout=10,
    )
    r.raise_for_status()
    return r.json()


def validate_token() -> bool:
    try:
        r = requests.post(
            f"{SERVER_URL}/api/auth/validate",
            headers=_get_headers(),
            timeout=5,
        )
        return r.status_code == 200
    except Exception:
        return False


def post_event(event_type: str, data: dict) -> bool:
    global _last_position_post

    # Debounce position updates — standings change slowly, no need to spam
    if event_type == "position_update":
        now = time.time()
        with _lock:
            if now - _last_position_post < POSITION_POST_INTERVAL:
                return True  # silently skip
            _last_position_post = now

    try:
        r = requests.post(
            f"{SERVER_URL}/api/iracing/event",
            json={"event": event_type, "data": data},
            headers=_get_headers(),
            timeout=5,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[API] Failed to send {event_type}: {e}")
        return False


def get_status() -> dict | None:
    try:
        r = requests.get(
            f"{SERVER_URL}/api/iracing/status",
            headers=_get_headers(),
            timeout=5,
        )
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None


def get_client_version() -> dict | None:
    """Fetch latest version info from server for auto-update check."""
    try:
        r = requests.get(f"{SERVER_URL}/api/client/version", timeout=5)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None
