import threading
import time
import irsdk
from config import POLL_INTERVAL_SECONDS

NEARBY_WINDOW = 2  # cars ahead/behind to include in nearby list


class IRacingMonitor:
    """
    Polls iRacing shared memory every POLL_INTERVAL_SECONDS.
    Fires on_event(event_type, data) for:
      - 'driver_change'   when the driver in our car changes
      - 'fuel_update'     current fuel level + estimated time remaining
      - 'position_update' overall pos, class pos, lap data, nearby cars + gaps
    """

    def __init__(self, on_event, on_status_change=None):
        self.ir = irsdk.IRSDK()
        self.on_event = on_event
        self.on_status_change = on_status_change
        self._running = False
        self._thread = None
        self._last_driver_name = None
        self._connected = False

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def is_connected(self):
        return self._connected

    def _set_status(self, msg: str):
        print(f"[Monitor] {msg}")
        if self.on_status_change:
            self.on_status_change(msg)

    def _loop(self):
        self._set_status("Starting — waiting for iRacing...")
        while self._running:
            try:
                if not self.ir.is_initialized:
                    ok = self.ir.startup()
                    if not ok:
                        if self._connected:
                            self._connected = False
                            self._set_status("iRacing not detected. Waiting...")
                        time.sleep(5)
                        continue

                if not self.ir.is_connected:
                    if self._connected:
                        self._connected = False
                        self._set_status("iRacing closed. Waiting...")
                    time.sleep(5)
                    continue

                if not self._connected:
                    self._connected = True
                    self._set_status("Connected to iRacing ✓")

                self.ir.freeze_var_buffer_latest()
                self._read_data()

            except Exception as e:
                self._set_status(f"Error: {e}")
                time.sleep(5)
                try:
                    self.ir.shutdown()
                except Exception:
                    pass

            time.sleep(POLL_INTERVAL_SECONDS)

    def _read_data(self):
        try:
            self._check_driver()
            self._check_fuel()
            self._check_position()
        except Exception as e:
            print(f"[Monitor] Read error: {e}")

    # ── Driver change ──────────────────────────────────────────

    def _check_driver(self):
        try:
            driver_idx = self.ir["PlayerCarIdx"]
            if driver_idx is None:
                return
            drivers = self.ir["DriverInfo"]["Drivers"]
            if not drivers:
                return
            current = next((d for d in drivers if d.get("CarIdx") == driver_idx), None)
            if not current:
                return
            name = current.get("UserName", "").strip()
            user_id = str(current.get("UserID", ""))
            session_time = self.ir["SessionTime"] or 0
            if name and name != self._last_driver_name:
                self._last_driver_name = name
                self.on_event("driver_change", {
                    "driver_name": name,
                    "driver_id": user_id,
                    "session_time": round(session_time, 2),
                })
        except Exception as e:
            print(f"[Monitor] Driver check error: {e}")

    # ── Fuel ──────────────────────────────────────────────────

    def _check_fuel(self):
        try:
            fuel_level = self.ir["FuelLevel"]
            fuel_pct = self.ir["FuelLevelPct"]
            fuel_use_per_hour = self.ir["FuelUsePerHour"]
            session_time = self.ir["SessionTime"] or 0
            if fuel_level is None:
                return
            mins_remaining = None
            if fuel_use_per_hour and fuel_use_per_hour > 0.01:
                mins_remaining = round((fuel_level / fuel_use_per_hour) * 60, 1)
            self.on_event("fuel_update", {
                "fuel_level": round(fuel_level, 3),
                "fuel_pct": round(fuel_pct or 0, 4),
                "mins_remaining": mins_remaining,
                "session_time": round(session_time, 2),
            })
        except Exception as e:
            print(f"[Monitor] Fuel check error: {e}")

    # ── Position, standings, gaps ─────────────────────────────

    def _check_position(self):
        try:
            player_idx = self.ir["PlayerCarIdx"]
            if player_idx is None:
                return

            car_idx_position       = self.ir["CarIdxPosition"]
            car_idx_class_position = self.ir["CarIdxClassPosition"]
            car_idx_f2time         = self.ir["CarIdxF2Time"]
            car_idx_lap            = self.ir["CarIdxLap"]
            car_idx_last_lap       = self.ir["CarIdxLastLapTime"]
            car_idx_best_lap       = self.ir["CarIdxBestLapTime"]
            car_idx_lap_dist_pct   = self.ir["CarIdxLapDistPct"]

            if not car_idx_position:
                return

            drivers = self.ir["DriverInfo"]["Drivers"] or []
            driver_map = {d["CarIdx"]: d for d in drivers}

            my_pos       = car_idx_position[player_idx]
            my_class_pos = car_idx_class_position[player_idx] if car_idx_class_position else None
            my_lap       = car_idx_lap[player_idx] if car_idx_lap else None
            my_last_lap  = car_idx_last_lap[player_idx] if car_idx_last_lap else None
            my_best_lap  = car_idx_best_lap[player_idx] if car_idx_best_lap else None
            my_gap       = car_idx_f2time[player_idx] if car_idx_f2time else None
            my_lap_pct   = car_idx_lap_dist_pct[player_idx] if car_idx_lap_dist_pct else None

            standings = []
            for idx, pos in enumerate(car_idx_position):
                if pos <= 0:
                    continue
                d = driver_map.get(idx, {})
                gap_raw = car_idx_f2time[idx] if car_idx_f2time else None
                standings.append({
                    "car_idx":       idx,
                    "position":      pos,
                    "class_pos":     car_idx_class_position[idx] if car_idx_class_position else None,
                    "driver_name":   d.get("UserName", f"Car {idx}"),
                    "car_number":    d.get("CarNumber", "?"),
                    "car_class":     d.get("CarClassShortName", ""),
                    "lap":           car_idx_lap[idx] if car_idx_lap else None,
                    "last_lap":      self._fmt_laptime(car_idx_last_lap[idx] if car_idx_last_lap else None),
                    "best_lap":      self._fmt_laptime(car_idx_best_lap[idx] if car_idx_best_lap else None),
                    "gap_to_leader": self._fmt_gap(gap_raw),
                    "gap_raw":       gap_raw,
                    "is_player":     idx == player_idx,
                })

            standings.sort(key=lambda x: x["position"])

            nearby = []
            for car in standings:
                delta_pos = car["position"] - my_pos
                if abs(delta_pos) <= NEARBY_WINDOW:
                    gap_to_us = None
                    if car["gap_raw"] is not None and my_gap is not None:
                        raw = car["gap_raw"] - my_gap
                        gap_to_us = f"+{raw:.3f}s" if raw >= 0 else f"{raw:.3f}s"
                    nearby.append({
                        **car,
                        "delta_position": delta_pos,
                        "gap_to_us": gap_to_us,
                    })

            self.on_event("position_update", {
                "position":       my_pos,
                "class_position": my_class_pos,
                "lap":            my_lap,
                "last_lap":       self._fmt_laptime(my_last_lap),
                "best_lap":       self._fmt_laptime(my_best_lap),
                "gap_to_leader":  self._fmt_gap(my_gap),
                "lap_dist_pct":   round(my_lap_pct, 4) if my_lap_pct is not None else None,
                "nearby":         nearby,
                "standings":      standings,
                "session_time":   round(self.ir["SessionTime"] or 0, 2),
            })

        except Exception as e:
            print(f"[Monitor] Position check error: {e}")

    @staticmethod
    def _fmt_laptime(seconds):
        if seconds is None or seconds <= 0:
            return None
        m = int(seconds // 60)
        s = seconds % 60
        return f"{m}:{s:06.3f}"

    @staticmethod
    def _fmt_gap(f2time):
        if f2time is None or f2time < 0:
            return None
        if f2time == 0:
            return "Leader"
        return f"+{f2time:.3f}s"
